/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#include <react/renderer/components/FBReactNativeSpec/Props.h>

#warning \
    "[DEPRECATION] `react/renderer/components/rncore/Props.h` is deprecated and will \
    be removed in the future. If this warning appears due to a library, please open \
    an issue in that library, and ask for an update. Please, replace the `rncore` \
    imports  with `FBReactNativeSpec` or remove them entirely.
